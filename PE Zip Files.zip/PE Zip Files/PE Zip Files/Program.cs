﻿using System;

namespace PE_Zip_Files
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Zip it and ship it");
            Console.WriteLine("My name is Yaroslav Mikhnevych :)");
        }
    }
}
